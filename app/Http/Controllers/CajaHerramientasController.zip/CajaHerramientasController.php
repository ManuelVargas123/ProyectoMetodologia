<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\CajaHerramienta;
use App\Herramienta;
use App\Empleado;
use App\Historial;
use App\HerramientaEnCaja;
use App\EmpleadoCaja;

class CajaHerramientasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $caja_herramientas = CajaHerramienta::get();

        $empleados = Empleado::all();

        return view('cajas_herramientas')->with([
            'caja_herramientas' => $caja_herramientas,
            'empleados' => $empleados
        ]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cajaHerramienta = new CajaHerramienta;
        $cajaHerramienta->notas = $request->notas;

        //Informacion del usuario
        $usuario = auth()->user();

        //Historial
        $historial = new Historial;
        $historial->user_id = $usuario->id;
        if($usuario->is_admin === 1)
            $historial->rol = "Administrador";
        else
            $historial->rol = "Gerente";
        $historial->accion = "Agregar";
        $historial->tabla = "Caja de Herramientas";
        
        $caja = CajaHerramienta::all();
        if ($caja->count())
            $caja_id = CajaHerramienta::orderBy('id', 'DESC')->first()->id;

        $historial->objeto = "Caja #";
        if(empty($caja_id))
            $historial->objeto .= "1";
        else
            $historial->objeto .= $caja_id + 1;
        $historial->save();

        if($cajaHerramienta->save())
        {
            if(!empty($request->empleado1))
                $cajaHerramienta->empleados()->attach($request->empleado1);
            
            if(!empty($request->empleado2))
                $cajaHerramienta->empleados()->attach($request->empleado2);
            
            return redirect()->back()->with('success', 'Has agregado una nueva Caja de Herramientas correctamente');
        } else {
            return redirect()->back()->with('error', 'Ocurrió un error al intentar agregar una Caja de Herramientas, intentalo de nuevo.');
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $cajaHerramienta = CajaHerramienta::find($id);

        $empleados = EmpleadoCaja::select('empleado_id')->where('caja_id', $id)->get();

        return response()->json([
            'id' => $cajaHerramienta->id,
            'empleados' => $empleados,
            'notas' => $cajaHerramienta->notas
        ]);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = $request->id;

        $cajaHerramienta = CajaHerramienta::find($id);
        $cajaHerramienta->notas = $request->notas;

        //Informacion del usuario
        $usuario = auth()->user();

        //Historial
        $historial = new Historial;
        $historial->user_id = $usuario->id;
        if($usuario->is_admin === 1)
            $historial->rol = "Administrador";
        else
            $historial->rol = "Gerente";
        $historial->accion = "Modificar";
        $historial->tabla = "Caja de Herramientas";
        $historial->objeto = "Caja #";
        $historial->objeto .= $id;
        $historial->save();

        if($cajaHerramienta->save())
        {
            if(empty($request->empleado1)){
                $empleado = new Empleado;
                $empleado->cajaHerramientas()->detach($id);
            }
            else
                $cajaHerramienta->empleados()->sync($request->empleado1);
            
            if(empty($request->empleado2))
            {
                $empleado = new Empleado;
                $empleado->cajaHerramientas()->detach($id);
            }
            else
                $cajaHerramienta->empleados()->syncWithoutDetaching($request->empleado2);

            return redirect()->back()->with('success', 'Has editado una nueva Caja de Herramientas correctamente');
        } else {
            return redirect()->back()->with('error', 'Ocurrió un error al intentar editar una Caja de Herramientas, intentalo de nuevo.');
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cajaHerramienta = CajaHerramienta::find($id); // Buscamos el registro

        //Informacion del usuario
        $usuario = auth()->user();

        //Historial
        $historial = new Historial;
        $historial->user_id = $usuario->id;

        if($usuario->is_admin === 1)
            $historial->rol = "Administrador";
        else
            $historial->rol = "Gerente";

        $historial->accion = "Eliminar";
        $historial->tabla = "Caja de Herramientas";
        $historial->objeto = "Caja #";
        $historial->objeto .= $cajaHerramienta->id;
        $historial->save();

        //Para eliminar de la tabla de relacion
        $cajaHerramienta->herramientas()->detach();
        $cajaHerramienta->empleados()->detach();

        if($cajaHerramienta->delete()) {   // Lo eliminamos
            return redirect()->back()->with('success', 'Has eliminado una caja de herramientas correctamente.');
        } else {
            return redirect()->back()->with('error', 'Ocurrió un error al intentar eliminar una caja de herramientas, intentalo de nuevo.');
        }
    }
}
